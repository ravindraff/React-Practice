import logo from './logo.svg';
import './App.css';
import Button from "./components/button/Button";

function App() {
  return (
    <div>
        <Button label="click me"></Button>
    </div>
  );
}

export default App;
