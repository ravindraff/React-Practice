interface Product{
    "_id":string;
    "name":string;
    "category":string;
    "image":string;
    "price":number
};
export default Product;