import React from "react";

export default React.memo((props:any)=>{
   
    return(<h1>{props.key1}</h1>)
});