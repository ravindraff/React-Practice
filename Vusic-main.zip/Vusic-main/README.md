<h1 align="center">
   Vusic | The music destination you want.
</h1>

<div align="center">

![Home Page](https://drive.google.com/uc?id=1ayxhKGDHtysZPMqti6k4ZY072nm3I3MZ)

    A music app made with the help of React.js.
    
</div>

## TECHNOLOGY USED

* ### [React.js](https://reactjs.org/)
    * ###### [react-router](https://github.com/ReactTraining/react-router#readme)
    * ###### [react-redux](https://react-redux.js.org/)
    * ###### [material-ui/core](https://www.npmjs.com/package/@material-ui/core)
    * ###### [material-ui/icons](https://www.npmjs.com/package/@material-ui/icons)
    * ###### [context API](https://reactjs.org/docs/context.html)
    * ###### [scss](https://sass-lang.com/)
   

## Attribution
    
[Icons](www.flaticon.com) made by Freepikfrom 

[Music](https://ncs.io/music) by NCS

    Please make sure you fork the repository
