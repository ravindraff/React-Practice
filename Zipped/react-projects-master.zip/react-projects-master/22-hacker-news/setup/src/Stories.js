import React from 'react'

import { useGlobalContext } from './context'

const Stories = () => {
  return <h2>stories component</h2>
}

export default Stories
